print("Enter the 1st number")
num1=int(input())
print("Enter the 2nd number")
num2=int(input())

print("Enter the Operation")
operation=input()

if operation=="+":
    print("the addition of two numbers is",num1+num2)
    elif operation == "-":
        print("the addition of two numbers is", num1 - num2)

        print("the asubstraction of two numbers is", num1 - num2)

        print("enter the valid input")











