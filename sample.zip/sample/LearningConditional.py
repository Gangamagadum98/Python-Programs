weather="cloudy"

if weather=="raining":
    print("watch tv")
elif weather=="cloudy":
    print("walking")
else:
    print("play outside")
