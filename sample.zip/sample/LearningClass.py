#creating a design
class Car:
    color="blue"
    price="1.2cr"

#create Objects using class
lexus=Car()
print(lexus.color)
print(lexus.price)

class Flat:
    NoofBedrooms=4
    area="Basavanagudi"
    price=400000

firstflr=Flat()
print(firstflr.NoofBedrooms)
print(firstflr.area)
print(firstflr.price)

secondflr=Flat()
print(secondflr.NoofBedrooms)
print(secondflr.area)
print(secondflr.price)

thirdflr=Flat()
print(thirdflr.NoofBedrooms)
print(thirdflr.area)
print(thirdflr.price)






