vowels=["a","e","i","o","u"]
print("Enter the alphabet")
userInput=input()

if vowels.__contains__(userInput):
    print("its a vowel")
else:
    print("its a consonent")









