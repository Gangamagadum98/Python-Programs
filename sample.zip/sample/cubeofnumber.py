num1={1,2,3}
num1=int(input())
print("Enter the number")

num=cube(num1)