# str1= "Hi java script"
# str2 = "Hoe are you"
# print(str1[0:5])
# print(str1[0])
# print(str1+str2)
# print(str1*2)
# print(str2[4])
# print(str1[2:])
# print(str2[:5])
