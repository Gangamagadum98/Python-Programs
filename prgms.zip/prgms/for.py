x=["mansa",89,78.90]
for i in x:
    print(i)

for i in ["jyotu",8,8]:
    print(i)

for i in range(10):
    print(i)

for i in range(11,21,2):
    print(i)

for i in range(20,11,-2):
    print(i)

for i in range(1,21):
    if(i%5!=0):
        print(i)