i=1
num = int(input("enter a number of multiplications u want"))
for i in range (1,11):
    print("%dX%d=%d"%(num,i,num*i))

