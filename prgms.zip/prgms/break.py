av=5
x = int(input("Enter how many candies do you want!"))
i=1
while i<=x:

    if i>av:
        break;
    print("candy")
    i+=1

print("bye")