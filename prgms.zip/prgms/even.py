num=int(input("enter number"))
if num%2==0:
    print("num is even")
else:
    print("num is not even")