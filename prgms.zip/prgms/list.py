l=[1,"Hi","python",2]
print(l[3:])
print(l[1:])
print(l[2:5])
print(l+l)
print(l*2)
print(l[:2])
