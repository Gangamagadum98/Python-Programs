# Taking input value from user
x=int(input("Enter 1st number"))
y=int(input("Enter 2ns number"))
print(x+y)