for i in range(0,5):
    print(i)
    break
else: print("for loop is exhausted")
print("came out of for loop")