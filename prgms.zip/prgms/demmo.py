from Calc import *

a=3
b=2

c=mul(a,b)
print(c)

