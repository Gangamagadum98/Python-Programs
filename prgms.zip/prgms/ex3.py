n=int(input("enter a num"))
i,j=0,0
for i in range(0,n):
    print(" ")
    for j in range(0,i+1):
        print("*",end=)