str='python'
for i in str:
    if i=='o':
        break
    print(i)
    