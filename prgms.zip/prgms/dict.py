d={1:"Ganga",2:34,3:"magadum",4:"s"}
print("First name is"+d[1])
print("second name is"+d[3])
print(d[2])
print(d)
print(d.values())
print(d.keys())
print()