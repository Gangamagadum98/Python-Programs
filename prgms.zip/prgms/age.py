age=int(input("enter your age?"))
if age>=18:
    print("You are allow to vote")
else:
    print("you are not eligible for vote")