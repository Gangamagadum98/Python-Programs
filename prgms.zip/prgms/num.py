a=10
b=5.78
c="hi python"
print(type(a))
print(type(b))
print(type(c))
