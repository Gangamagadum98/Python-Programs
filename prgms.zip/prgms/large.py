a=int(input("enter a?"))
b=int(input("enter b?"))
c=int(input("enter c?"))
if a>b and a>c:
    print("a is greater")
if b>a and b>c:
    print("b is greater")
if c>a and c>b:
    print("c is greater")
    