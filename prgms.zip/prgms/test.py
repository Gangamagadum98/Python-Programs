import  main

print("Hello")
print((__name__))