num= int(input("Enter a number"))
if num%2==0:
    print("Given no is even")
else:
    print("no is odd")
    