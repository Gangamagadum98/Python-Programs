class Politician:
    name="xyz"
    party="abc"

    def scam(self):
        self.money="400cr"

pol=Politician()
pol.scam()
print(pol.money)

