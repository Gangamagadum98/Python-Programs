
class Actor:
    name="abc"
   
    def __init__(self):
       self.age=45

    def acting(self):
        print("best dancer")

act=Actor()
print(act.name)






